import os
import numpy as np
import pandas as pd
import collections
import json
import csv
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import rcParams
# from sample import *

datadir='.'
end = 'adaptive_avg_pool2d_nsight.csv'
files=[x for x in os.listdir(datadir) if x.endswith(end)]
files.sort()
files=[os.path.join(datadir,file) for file in files]
dfs={}


# repeat_number = pd.read_csv(open("adaptive_avg_pool2d_repeat_number.csv"))
# ALL_NUMBER = np.sum(repeat_number.values)
NUM_Metrics = 21
# NUM_DEDU = len(repeat_number.values)

def get_input_output_data():
    with open("adaptive_avg_pool2d.json", "r") as f:
        arg_data = json.load(f)
    arg_data_length = len(arg_data["input_size"])
    in_sizes = []
    out_sizes = []
    kernel_sizes = []
    for i in range(arg_data_length):
        in_size = 1
        in_HW_size = 1
        idx = 0
        for dim in arg_data["input_size"][i]:
            in_size *= dim
            if idx == 2 or idx == 3: # HW
                in_HW_size *= dim
            idx += 1
        in_sizes.append(in_size)
        out_size = 1
        for dim in arg_data["output_size"][i]:
            out_size *= dim
        out_sizes.append(out_size * in_size/ in_HW_size)
        kernel_sizes.append(in_HW_size/out_size)
    return in_sizes, out_sizes, kernel_sizes

def get_dedu_input_data():
    with open("adaptive_avg_pool2d_dedu.json", "r") as f:
        arg_data = json.load(f)
    arg_data_length = len(arg_data["input_size"])
    in_sizes = []
    out_sizes = []
    kernel_sizes = []
    for i in range(arg_data_length):
        if arg_data["input_size"][i][0] * arg_data["input_size"][i][1] * arg_data["input_size"][i][2] * arg_data["input_size"][i][3]:
            in_size = 1
            in_HW_size = 1
            idx = 0
            for dim in arg_data["input_size"][i]:
                in_size *= dim
                if idx == 2 or idx == 3: # HW
                    in_HW_size *= dim
                idx += 1
            out_size = 1
            for dim in arg_data["output_size"][i]:
                out_size *= dim
            in_sizes.append(in_size)
            out_sizes.append(out_size)
            kernel_sizes.append(in_size/in_HW_size)
        # if in_size/in_HW_size > 2048:
        #     kernel_sizes.append(in_HW_size/out_size)
        # kernel_sizes.append(in_HW_size * out_size)
    return in_sizes, out_sizes, kernel_sizes

def get_dedu_input_info():
    with open("adaptive_avg_pool2d_dedu.json", "r") as f:
        arg_data = json.load(f)
    arg_data_length = len(arg_data["input_size"])
    in_infos = []
    out_infos = []
    kernel_infos = []
    for i in range(arg_data_length):
        if arg_data["input_size"][i][0] * arg_data["input_size"][i][1] * arg_data["input_size"][i][2] * arg_data["input_size"][i][3] :
            in_info = str(arg_data["input_size"][i][0])
            for dim in range(len(arg_data["input_size"][i])-1):
                in_info += "x" + str(arg_data["input_size"][i][dim+1])
            # in_info += "  " + str(arg_data["output_size"][i][0]) + "x" + str(arg_data["output_size"][i][1])
            in_infos.append(in_info)
            out_info =  str(arg_data["output_size"][i][0]) + "x" + str(arg_data["output_size"][i][1])
            out_infos.append(out_info)
            
            # kernel_info = str(arg_data["input_size"][i][2]//arg_data["output_size"][i][0] * arg_data["input_size"][i][3]//arg_data["output_size"][i][1])
            # kernel_info = str(arg_data["input_size"][i][0] * arg_data["input_size"][i][1])
            # kernel_info = str(arg_data["input_size"][i][0] * arg_data["input_size"][i][1] * arg_data["input_size"][i][2] * arg_data["input_size"][i][3] /  arg_data["output_size"][i][0] // arg_data["output_size"][i][1])
            kernel_info = in_info + " " + str(arg_data["output_size"][i][0]) + " " + str(arg_data["output_size"][i][1])
            # kernel_info = str(arg_data["output_size"][i][0]) + str(arg_data["output_size"][i][1]) + str(arg_data["input_size"][i][0]) +  str(arg_data["input_size"][i][0]) 
            NC_size =  arg_data["input_size"][i][0] * arg_data["input_size"][i][1]
            # if NC_size > 2048:
            #     kernel_infos.append(kernel_info)
            kernel_infos.append(kernel_info)
    return in_infos,out_infos,kernel_infos

with open("adaptive_avg_pool2d_dedu.json", 'r') as f:
    shape_dict = json.load(f)

for file in files:
    tag, ext = os.path.splitext(os.path.basename(file))
    dfs[tag]=pd.DataFrame()
    with open(file,'r') as f:
        df = pd.read_csv(file)
        df_group=pd.DataFrame()
        dft=pd.DataFrame(df, columns=['ID', 'Kernel Name','Metric Name', 'Metric Value'])
        
        dft['Metric Value'] = pd.to_numeric(dft['Metric Value'].str.replace(r',',''))
        dfmetric=pd.pivot_table(dft, index=['ID'], columns=['Metric Name'], values=['Metric Value'])
        dfmetric.to_csv("tmp.csv")
        kernel_name = dft['Kernel Name']
        kernel_name_dedu = []
        for k in range(0,len(kernel_name),NUM_Metrics):
            kernel_name_dedu.append(kernel_name[k])
        df_kernel_name_dedu=pd.DataFrame(kernel_name_dedu,columns=['Kernel Name'])

    
        csv_reader = csv.reader(open("tmp.csv"))
        os.remove("tmp.csv")
        count = 0
        with open("nsight_result.csv", 'w') as f:
            csv_writer = csv.writer(f)
            for line in csv_reader:
                if count != 0 and count != 2:
                    csv_writer.writerow(line)
                count += 1
            f.close
        count -= 2
        
        dfmetric = pd.read_csv(open("nsight_result.csv"))


        dfmetric['Time']=dfmetric['sm__cycles_elapsed.avg'] \
                        / (dfmetric['sm__cycles_elapsed.avg.per_second'] )
        dfmetric['Kernel Name'] = df_kernel_name_dedu['Kernel Name']

        df_list = ['Time', 'sm__sass_thread_inst_executed_op_dfma_pred_on.sum', 
         'sm__sass_thread_inst_executed_op_dmul_pred_on.sum', 
         'sm__sass_thread_inst_executed_op_dadd_pred_on.sum', 
         'sm__sass_thread_inst_executed_op_ffma_pred_on.sum', 
         'sm__sass_thread_inst_executed_op_fmul_pred_on.sum', 
         'sm__sass_thread_inst_executed_op_fadd_pred_on.sum', 
         'sm__sass_thread_inst_executed_op_hfma_pred_on.sum', 
         'sm__sass_thread_inst_executed_op_hmul_pred_on.sum', 
         'sm__sass_thread_inst_executed_op_hadd_pred_on.sum', 
         'sm__inst_executed_pipe_tensor.sum',
         'gpu__compute_memory_throughput.avg.pct_of_peak_sustained_elapsed',
         'l1tex__throughput.avg.pct_of_peak_sustained_elapsed',
         'lts__throughput.avg.pct_of_peak_sustained_elapsed',
         'dram__bytes.sum',
         'lts__t_bytes.sum',
         'l1tex__t_bytes.sum']

        df_dict = {i: []
        for i in df_list
         }
        
        cur_line = 0
        kernel_keys = "at::native::"
        k_start = False
        for index, kernel in dfmetric.iterrows():
            if kernel_keys in kernel['Kernel Name'].lower():
                for j in range(len(df_list)):
                    curnum = 0.0
                    for i in range(cur_line, cur_line+1):
                        curnum += float(dfmetric[df_list[j]][i])
                    df_dict[df_list[j]].append(curnum)
            cur_line += 1
        assert len(df_dict['Time']) == NUM_DEDU
        
        header = df_dict.keys()
        rows=pd.DataFrame(df_dict).to_dict('records')
        
        with open('deal.csv', 'w') as f:
            f.write(','.join(header))
            f.write('\n')
            for data in rows:
                f.write(",".join(str(data[h]) for h in header))
                f.write('\n')

        dfmetric = pd.read_csv(open("deal.csv"))
        os.remove("deal.csv")
        for i in df_list:
            dfmetric[i] = pd.to_numeric(dfmetric[i])


        dfmetric['CC FLOPs']= 2 * dfmetric['sm__sass_thread_inst_executed_op_dfma_pred_on.sum'] \
                            + dfmetric['sm__sass_thread_inst_executed_op_dmul_pred_on.sum'] \
                            + dfmetric['sm__sass_thread_inst_executed_op_dadd_pred_on.sum'] \
                            + 2 * dfmetric['sm__sass_thread_inst_executed_op_ffma_pred_on.sum'] \
                            + dfmetric['sm__sass_thread_inst_executed_op_fmul_pred_on.sum'] \
                            + dfmetric['sm__sass_thread_inst_executed_op_fadd_pred_on.sum'] \
                            + 2 * dfmetric['sm__sass_thread_inst_executed_op_hfma_pred_on.sum'] \
                            + dfmetric['sm__sass_thread_inst_executed_op_hmul_pred_on.sum'] \
                            + dfmetric['sm__sass_thread_inst_executed_op_hadd_pred_on.sum'] 

        dfmetric['TC FLOPs']= 512 * dfmetric['sm__inst_executed_pipe_tensor.sum']
        dfmetric['all FLOPs']= dfmetric['CC FLOPs'] + dfmetric['TC FLOPs']
        
        dfmetric['AI HBM'] = dfmetric['all FLOPs'].div(dfmetric['dram__bytes.sum'])
        dfmetric['AI L2'] = dfmetric['all FLOPs'].div(dfmetric['lts__t_bytes.sum'])
        dfmetric['AI L1'] = dfmetric['all FLOPs'].div(dfmetric['l1tex__t_bytes.sum'])

        dfmetric['GFLOP/s'] = dfmetric['all FLOPs']/ dfmetric['Time'] /1024/1024/1024
        dfmetric['TC GFLOP/s'] = dfmetric['TC FLOPs']/ dfmetric['Time'] /1024/1024/1024

        print(dfmetric['AI L2'].values)
        print(np.sum(dfmetric['AI L2'].values) / len(dfmetric['AI L2'].values))
        dfmetric.to_csv('pd.csv')
        dfs[tag]=dfmetric

        in_infos, out_infos, kernel_infos = get_dedu_input_info()
        sizes, out_sizes, kernel_sizes  = get_dedu_input_data()

        # metric = 'gpu__compute_memory_throughput.avg.pct_of_peak_sustained_elapsed'
        # metric = 'lts__throughput.avg.pct_of_peak_sustained_elapsed'
        # metric = 'l1tex__throughput.avg.pct_of_peak_sustained_elapsed'
        # metric = 'Time'

        plt_metrics = ['gpu__compute_memory_throughput.avg.pct_of_peak_sustained_elapsed',
                        'lts__throughput.avg.pct_of_peak_sustained_elapsed',
                        'l1tex__throughput.avg.pct_of_peak_sustained_elapsed', 'Time']

        plt_size = [[-10, "1x20x64x64"], [-11, "4x256x64x64"], [-12, "2x2048x64x64"], [-12, "4x2048x64x64"]]
        plt_rect = []
        # DEDU
        # in_size_utilzation_dict = collections.OrderedDict()
        for i in range(4):
            for j in range(4):
                in_size_utilzation_dict = collections.OrderedDict()
                for idx, in_size in enumerate(sizes):
                    metric = plt_metrics[i]
                    slice_idx = plt_size[j][0]
                    plt_size_info = plt_size[j][1]
                    
                    if in_infos[idx][slice_idx:] == plt_size_info:
                        in_size += out_sizes[idx]*1.0/1e6 
                        if in_size in in_size_utilzation_dict.keys() and abs(in_size_utilzation_dict[in_size][0]-dfmetric[metric].values[idx]) > 10 and in_size_utilzation_dict[in_size][1] == in_infos[idx]:
                            print("before", in_size_utilzation_dict[in_size], "and now",  [dfmetric[metric].values[idx], in_infos[idx], out_infos[idx]])
                        in_size_utilzation_dict[in_size] = [dfmetric[metric].values[idx], in_infos[idx], out_infos[idx]]
                plt_rect.append(collections.OrderedDict(sorted(in_size_utilzation_dict.items())))
                # print('-----------------------------------')
                # print(plt_rect[-1])
            # if in_infos[idx][-10:] == "1x20x64x64" :#in_size >= 256 * 8 * 40 * 40:
            # if in_infos[idx][-11:] == "4x256x64x64" :
            # if in_infos[idx][-12:] == "4x2048x64x64" :
            # if in_infos[idx][-11:] == "2x256x97x97" :
            # if in_infos[idx][-11:] == "2x512x97x97" :
            # if in_infos[idx][-12:] == "2x2048x97x97" :
                # in_size += out_sizes[idx]*1.0/1e6 
                # if in_size in in_size_utilzation_dict.keys() and abs(in_size_utilzation_dict[in_size][0]-dfmetric[metric].values[idx]) > 10 and in_size_utilzation_dict[in_size][1] == in_infos[idx]:
                #     print("before", in_size_utilzation_dict[in_size], "and now",  [dfmetric[metric].values[idx], in_infos[idx], out_infos[idx]])
                # in_size_utilzation_dict[in_size] = [dfmetric[metric].values[idx], in_infos[idx], out_infos[idx]]
        print('-----------------------------')


        fig, axs = plt.subplots(4, 4, figsize=(12, 10), sharex='col', sharey='row', layout='constrained')

        # for ax in axs.flat:
        #     ax.bar()
        font = { 'size'   : 14}
        plt.rc('font', **font)
        rcParams['font.serif'] = ['Times New Roman']
        fontsize_tune = 12
        colors = ['tab:orange', 'tab:blue', 'tab:brown', 'tab:olive', 'tab:red', 'tab:green']
        for i in range(4):
            for j in range(4):
                ax = axs[i, j]
                data_dict = plt_rect[j + i * 4]
                val_list = list(data_dict.values())
                # print(val_list)
                vals = [u[0] for u in val_list]
                names = [u[2] for u in val_list]
                ax.bar(names, vals, color=colors)
                # ax.set_ylabel(plt_metrics[i])
                # ax.set_xlabel(val_list[0][1])
                ax.tick_params(axis='x', labelsize=fontsize_tune)
                ax.tick_params(axis='y', labelsize=fontsize_tune)
                ax.set_xticks(range(0,len(names),1))
                # ax.set_yticks(range(0,101,20))
                ax.set_xticklabels(names) #,rotation=50

        data_dict = plt_rect[12]
        val_list = list(data_dict.values())
        axs[3, 0].set_xlabel('out tensor shape\n\n(i) in tensor shape=(1,20,64,64)' ) # + val_list[0][1]
        data_dict = plt_rect[13]
        val_list = list(data_dict.values())
        axs[3, 1].set_xlabel('out tensor shape\n\n(ii) in tensor shape=(4,256,64,64)')
        data_dict = plt_rect[14]
        val_list = list(data_dict.values())
        axs[3, 2].set_xlabel('out tensor shape\n\n(iii) in tensor shape=(2,2048,64,64)')
        data_dict = plt_rect[15]
        val_list = list(data_dict.values())
        axs[3, 3].set_xlabel('out tensor shape\n\n(iv) in tensor shape=(4,2048,64,64)')
        axs[0,0].set_ylabel('Global Memory Utilization(%)')
        axs[1,0].set_ylabel('L1 Cache Utilization(%)')
        axs[2,0].set_ylabel('L2 Cache Utilization(%)')
        axs[3,0].set_ylabel('Time(ms)')
        # axs[3,0].set_yticks(range())
        plt.savefig('pooling.perf.analysis.pdf', format='pdf', bbox_inches='tight')
        plt.savefig('pooling.perf.analysis.png', format='png', bbox_inches='tight')


        # in_size_utilzation_dict = collections.OrderedDict(sorted(in_size_utilzation_dict.items()))
        # print(in_size_utilzation_dict)
        # utilization_range_dict = {}
        # # init
        # column = 20
        # start = 0
        # step = 100 // column # 100%
        # label_data = []
        # for i in range(column):
        #     end = start + step
        #     key = str(start) + '-' + str(end)
        #     utilization_range_dict[key] = 0.0
        #     start += step
        #     label_data.append(key)

        # for idx, util in enumerate(dfmetric[metric].values):
        #     key = int(util // step)
        #     utilization_range_dict[label_data[key]] += int(repeat_number.values[idx]) / ALL_NUMBER * 100
        
        # print(len(in_size_utilzation_dict))
        # # -------------------------
        # import matplotlib.pyplot as plt

        # fontsize_tune = 8
        # title_size = 10
        # colors = ['tomato', 'lightskyblue', 'goldenrod', 'green', 'y']

        # allrown = 1
        # fig, axes = plt.subplots(nrows=allrown, ncols=1, figsize=(16,11*allrown))
        # plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=0.4, hspace=0.8)    #subplots创建多个子图


        # ########################## the first plt ################################
        # rown = 0
        # ax0 = axes

        # axis = ax0
        # # axis.set_ylabel('Memory Utilization(%)', fontsize=10)
        # # axis.set_ylabel('L2 Cache Utilization(%)', fontsize=10)
        # axis.set_ylabel('L1 Cache Utilization(%)', fontsize=10)
        # # axis.set_ylabel('Consume Time(ms)', fontsize=10)
        # data = list( i[0] for i in in_size_utilzation_dict.values())
        # names = list( (i[1] + " " + i[2]) for i in in_size_utilzation_dict.values())
        # axis.bar(names, data, color=colors)
        # # axis.set_title('Memory Utilization of adaptive_avg_pool2d Function with Different Parameters'
        #             # , fontsize=title_size)
        # # axis.set_title('L2 Cache Utilization of adaptive_avg_pool2d Function with Different Parameters'
        #             # , fontsize=title_size)
        # axis.set_title('L1 Cache Utilization of adaptive_avg_pool2d Function with Different Parameters'
        #             , fontsize=title_size)
        # # axis.set_title('Time duration of adaptive_avg_pool2d Function with Different Parameters'
        #             # , fontsize=title_size)
        # axis.tick_params(axis='x', labelsize=fontsize_tune)
        # axis.tick_params(axis='y', labelsize=fontsize_tune)
        # axis.set_xticks(range(0,len(names),1))
        # axis.set_yticks(range(0,101,20))
        # axis.set_xticklabels(names,rotation=50)
        # plt.savefig('adaptive_avg_pool2d_memory_utilization.png',dpi=800)
        
        ########################## the 2nd plt ################################
        # fig, axes = plt.subplots(nrows=allrown, ncols=1, figsize=(8,4*allrown))
        
        # ax0 = axes
        # axis = ax0
        # axis.set_ylabel('Ratio(%)', fontsize=10) 
        # names = list(utilization_range_dict.keys())
        # data = list(utilization_range_dict.values())

        # for x,y in zip(np.arange(len(names)),data):
        #     plt.text(x+0.05,y+0.05,'%.4f' %y, ha='center',va='bottom', fontdict={"size":4})

        # axis.bar(names, data, color=colors)
        # axis.set_title('Memory Utilization of adaptive_avg_pool2d Function with Different Parameters'
        #             , fontsize=title_size)
        # axis.tick_params(axis='x', labelsize=fontsize_tune)
        # axis.tick_params(axis='y', labelsize=fontsize_tune)
        # axis.set_xticks(range(0,len(names),1))
        # axis.set_xticklabels(names,rotation=70)
        # plt.savefig('adaptive_avg_pool2d_utilization_distribution.png',dpi=800)