import os
import numpy as np
import pandas as pd
from torch import cudnn_convolution
from roofline import roofline
import json
import csv

datadir='.'
# files=["./nsight_cudnn_conv_top3000.csv"]
# files.sort()
# files=[os.path.join(datadir,file) for file in files]
dfs={}
# kernel_nums = {"0": 1, "1": 2, "2": 2, "3": 0, "4": 5, "5": 4, "6": 2, "7": 4}


# with open("./top3000.json", 'r') as f:
#     shape_dict = json.load(f)
file = 'nsight162.csv'
tag, ext = os.path.splitext(os.path.basename(file))
dfs[tag]=pd.DataFrame()
with open(file, 'r') as f:
    df = pd.read_csv(file)
    df_group=pd.DataFrame()


    dft=pd.DataFrame(df, columns=['ID', 'Kernel Name','Metric Name', 'Metric Value'])
    dft['Metric Value'] = pd.to_numeric(dft['Metric Value'].str.replace(r',',''))
    dfmetric=pd.pivot_table(dft, index=['ID'], columns=['Metric Name'], values=['Metric Value'])
    dfmetric.to_csv("a.csv")
    csv_reader = csv.reader(open("a.csv"))
    count = 0
    with open("b.csv", 'w') as f:
        csv_writer = csv.writer(f)
        for line in csv_reader:
            if count != 0 and count != 2:
                csv_writer.writerow(line)
            count += 1
        f.close
    count -= 2
    
    dfmetric = pd.read_csv(open("b.csv"))


    dfmetric['Time']=dfmetric['sm__cycles_elapsed.avg'] \
                    / (dfmetric['sm__cycles_elapsed.avg.per_second'] )

    df_list = ['Time', 'sm__sass_thread_inst_executed_op_dfma_pred_on.sum', 
        'sm__sass_thread_inst_executed_op_dmul_pred_on.sum', 
        'sm__sass_thread_inst_executed_op_dadd_pred_on.sum', 
        'sm__sass_thread_inst_executed_op_ffma_pred_on.sum', 
        'sm__sass_thread_inst_executed_op_fmul_pred_on.sum', 
        'sm__sass_thread_inst_executed_op_fadd_pred_on.sum', 
        'sm__sass_thread_inst_executed_op_hfma_pred_on.sum', 
        'sm__sass_thread_inst_executed_op_hmul_pred_on.sum', 
        'sm__sass_thread_inst_executed_op_hadd_pred_on.sum', 
        'sm__inst_executed_pipe_tensor.sum',
        'dram__bytes.sum',
        'lts__t_bytes.sum',
        'l1tex__t_bytes.sum']

    df_dict = {i: []
    for i in df_list
        }
    cur_case = 0
    cur_line = 0
    # while cur_case < len(shape_dict["N"]):
    while cur_case < 162:
        # algo_t = shape_dict["algoMin"][cur_case][0]
        kernel_num = 1
        for j in range(len(df_list)):
            curnum = 0.0
            for i in range(cur_line, cur_line+kernel_num):
                curnum += float(dfmetric[df_list[j]][i])
            df_dict[df_list[j]].append(curnum)
        cur_line += kernel_num
        cur_case += 1

    header = df_dict.keys()
    rows=pd.DataFrame(df_dict).to_dict('records')
    
    with open('deal.csv', 'w') as f:
        f.write(','.join(header))
        f.write('\n')
        for data in rows:
            f.write(",".join(str(data[h]) for h in header))
            f.write('\n')

    dfmetric = pd.read_csv(open("deal.csv"))
    # os.remove("a.csv")
    # os.remove("b.csv")
    # os.remove("deal.csv")
    for i in df_list:
        dfmetric[i] = pd.to_numeric(dfmetric[i])


    dfmetric['CC FLOPs']= 2 * dfmetric['sm__sass_thread_inst_executed_op_dfma_pred_on.sum'] \
                        + dfmetric['sm__sass_thread_inst_executed_op_dmul_pred_on.sum'] \
                        + dfmetric['sm__sass_thread_inst_executed_op_dadd_pred_on.sum'] \
                        + 2 * dfmetric['sm__sass_thread_inst_executed_op_ffma_pred_on.sum'] \
                        + dfmetric['sm__sass_thread_inst_executed_op_fmul_pred_on.sum'] \
                        + dfmetric['sm__sass_thread_inst_executed_op_fadd_pred_on.sum'] \
                        + 2 * dfmetric['sm__sass_thread_inst_executed_op_hfma_pred_on.sum'] \
                        + dfmetric['sm__sass_thread_inst_executed_op_hmul_pred_on.sum'] \
                        + dfmetric['sm__sass_thread_inst_executed_op_hadd_pred_on.sum'] 

    dfmetric['TC FLOPs']= 512 * dfmetric['sm__inst_executed_pipe_tensor.sum']
    dfmetric['all FLOPs']= dfmetric['CC FLOPs'] + dfmetric['TC FLOPs']
    
    dfmetric['AI HBM'] = dfmetric['all FLOPs'].div(dfmetric['dram__bytes.sum'])
    dfmetric['AI L2'] = dfmetric['all FLOPs'].div(dfmetric['lts__t_bytes.sum'])
    dfmetric['AI L1'] = dfmetric['all FLOPs'].div(dfmetric['l1tex__t_bytes.sum'])

    dfmetric['GFLOP/s'] = dfmetric['all FLOPs']/ dfmetric['Time'] /1024/1024/1024
    dfmetric['TC GFLOP/s'] = dfmetric['TC FLOPs']/ dfmetric['Time'] /1024/1024/1024
    dfmetric.to_csv('pd_'+tag+'.csv')
    dfs[tag]=dfmetric


tags=dfs.keys()
flags=['HBM'] #'HBM','L2','L1' or 'all'
for tag in tags:
    for flag in flags:
        dfm=dfs[tag]
        LABELS = [str(i) for i in range(len(dfm.index.tolist()))]
        AIL1   = dfm['AI L1'].tolist()
        AIL2   = dfm['AI L2'].tolist()
        AIHBM  = dfm['AI HBM'].tolist()
        FLOPS  = dfm['GFLOP/s'].tolist()

        roofline(tag, FLOPS, AIHBM, AIL2, AIL1, LABELS, flag)

