import argparse
import torch
from torch.nn import functional
import numpy as np
import time
import logging
import json
# logging.basicConfig(filename="dropout.log",level=logging.DEBUG)
torch.backends.cudnn.allow_tf32=False
torch.backends.cuda.matmul.allow_tf32=False


def get_sample_config():
    with open("dropout_top592.json", "r") as f:
        arg_data = json.load(f)
    return arg_data

def profile(device):
    samples = get_sample_config()
    samples_num = len(samples)
    # print("samples ", samples_num)
    startTime = time.time()
    zero_p = 0
    for i in range(samples_num):
    #for i in range(20):
        # print(i, "#" * 20)
        case_args = samples[i]
        input_tensor = torch.from_numpy(np.ones(case_args['input_size'][0]).astype(np.float32)).cuda()
        p = case_args['p'][0]
        if type(p) == type([]):
            p = p[0]

        m = functional.dropout(input = input_tensor, p=p).cuda()

        logging.debug("finish " + str(i) + " time " + str(time.time()-startTime))



def main():
    # cuda settings
    use_cuda = torch.cuda.is_available()
    assert use_cuda == True, "cuda environment is not ready"
    device = torch.device("cuda")
    profile(device)
    # virtual_arg_profile()

if __name__ == '__main__':
    main()
