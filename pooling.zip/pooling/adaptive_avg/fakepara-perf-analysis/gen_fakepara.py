import json

def gen_fakapara(batch_size):
    data_dict = {'input_size':[], 'output_size':[]}
    c = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048]
    hw = [64, 97]
    output_size = [1, 2, 3, 4, 5, 6, 7, 8, 16, 32]
    for i in c:
        for j in hw:
            for k in output_size:
                data_dict['input_size'].append([batch_size, i, j, j])
                data_dict['output_size'].append([k, k])

    with open('./data/pooling_fakepara'+str(batch_size)+'.json', 'w') as f:
        json.dump(data_dict, f)


if __name__ == '__main__':
    batch_size = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096]
    for ele in batch_size:
        gen_fakapara(ele)