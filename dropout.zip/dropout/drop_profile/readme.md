### 脚本介绍
+ dropout_top592.json提供592个dropout算子参数样例. 其中430个的p取值为0,这些样例不会产生kernel, 故而最终profile中只有162个参数样例对应的kernel.
+ profile.py有两项功能: 解析参数 ; 跑取functional.dropout(), 跑取时关闭了tensorcore
+ run.sh 用sudo sh run.sh以启用ncu工具.
+ nsight_drop_592.csv 为跑取结果, 包含162个kernel:fused_dropout_kernel_vec, 就对应162个非0的p参数.
